老师，您直接使用这个快捷方式吧！
每次采集完图片可以运行一下save_img_to_another_path.py
把图片从默认路径剪切到   “./images/日期/当前时间/”  路径下