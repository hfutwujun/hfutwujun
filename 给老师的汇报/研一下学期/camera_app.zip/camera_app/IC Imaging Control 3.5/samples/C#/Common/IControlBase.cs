
internal interface IControlBase
{
    void UpdateControl();

}

internal interface IControlSlider
{
    void ScrollUpdate();

}