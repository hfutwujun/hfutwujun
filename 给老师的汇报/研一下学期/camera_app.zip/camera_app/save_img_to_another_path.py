import os
import fnmatch
import shutil
import datetime

time = datetime.datetime.now().strftime('%Y-%m-%d/%H_%M')  # 获取当前时间并转化成字符串

origin_img_path = './IC Imaging Control 3.5/redist/dotnet/x64'
new_img_path = './images/' + f'{time}/'

if not os.path.exists(new_img_path):
    os.makedirs(new_img_path)
    print('本次采集图片路径：', new_img_path)


def find_files(directory):
    file_list = []
    img_names = []
    for root, _, files in os.walk(directory):
        for basename in files:
            if fnmatch.fnmatch(basename, '*jpg') or fnmatch.fnmatch(basename, '*.bmp') or fnmatch.fnmatch(basename,
                                                                                                          '*.gif'):
                filename = os.path.join(root, basename)
                img_names.append(basename)
                file_list.append(filename)

    return file_list, img_names


if __name__ == '__main__':
    origin_imgs, names = find_files(origin_img_path)
    for i in range(len(origin_imgs)):
        shutil.copy(origin_imgs[i], new_img_path + names[i])
        os.remove(origin_imgs[i])
    print(f'图片剪切完成！\n共{len(origin_imgs)}张图片')
